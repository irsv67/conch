import {Injectable} from '@angular/core';

@Injectable()
export class FirstCompService {

    dataMap: any = {

        // ====include_start====

        // ====include_end====

    };

    constructor() {
    }

}
