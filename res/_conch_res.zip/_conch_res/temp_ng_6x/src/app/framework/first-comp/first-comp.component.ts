import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-first-comp',
    templateUrl: './first-comp.component.html',
    styleUrls: ['./first-comp.component.less']
})
export class FirstCompComponent implements OnInit {

    // ====include_start====

    // ====include_end====

    constructor() {
    }

    ngOnInit() {
        // ====init_start====

        // ====init_end====
    }

}
